import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


public class Main2014302580342 {

	public static ArrayList<File> waitList = new ArrayList<File>();

	public static void main(String[] args) throws InterruptedException, IOException{
		MultiThreading();
		Single_thread();
	}

	//���߳�
	public static void MultiThreading() throws InterruptedException{
		long startTime = System.currentTimeMillis();
		Buffer2014302580342 buffer = new Buffer2014302580342(waitList);
		Thread t1 = new Thread(new Crawler2014302580342(buffer));
		Thread t2 = new Thread(new DataProcess2014302580342(buffer));
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		System.out.println("���߳�: " + Long.toString(System.currentTimeMillis()-startTime)+"ms");
	}

	//���߳�
	public static void Single_thread() throws IOException{
		long startTime = System.currentTimeMillis();
		Buffer2014302580342 buffer = new Buffer2014302580342(waitList);
		Crawler2014302580342 c = new Crawler2014302580342(buffer);
		DataProcess2014302580342 d = new DataProcess2014302580342(buffer);
		ArrayList<File> pages = c.Crawl();
		for(File page:pages){
			d.getAllData(page);
		}
		System.out.println("���߳�: " + Long.toString(System.currentTimeMillis() - startTime)+"ms");
	}

}
