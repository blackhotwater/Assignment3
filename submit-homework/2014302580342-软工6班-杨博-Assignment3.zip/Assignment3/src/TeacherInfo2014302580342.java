
public class TeacherInfo2014302580342 {
	private String personalInfo;
	private String researchInterests;
	private String name;
	private String email;
	
	public String getEmail() {
		return email;
	}
	public String getResearchInterests() {
		return researchInterests;
	}
	public String getName(){
		return name;
	}
	public String getPersonalInfo(){
		return personalInfo;
	}
	
	public void setEmail(String e) {
		email = e;
	}
	public void setResearchInterests(String e) {
		researchInterests = e;
	}
	public void setName(String e){
		name = e;
	}
	public void setPersonalInfo(String e){
		personalInfo = e;
	}
}
