import java.io.IOException;
import java.io.File;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Crawler2014302580342 implements Runnable{
	private Buffer2014302580342 buffer;
	public static Boolean flag = false;
	
	Crawler2014302580342(Buffer2014302580342 b){
		this.buffer = b;
	}
	public static ArrayList<String> getURLs() throws IOException{
		//��url�ķ�ʽ����վ���ݴ�ŵ�doc��
		Document doc = Jsoup.connect("http://www.wpi.edu/academics/cs/research-interests.html").get();
		Elements links = doc.select(".half a");

		ArrayList<String> linkList = new ArrayList<String>();
		//��url���������
		for (Element link : links) {
			linkList.add(link.attr("href"));
		}
		return linkList;	 
	}
	
	//���߳�
	public File getHTMLFile(String url,String fileName){
		HttpRequest response = HttpRequest.get(url);
			File f = new File(fileName);
			response.receive(f);
			return f;
	}


	//���߳�ץȡ
	public ArrayList<File> Crawl() throws IOException{
		ArrayList<String> linkList = getURLs();
		ArrayList<File>  pages = new ArrayList<File>() ;
		
		for (String link : linkList){
			String fileName = "pages/" + link.replaceAll("http://www\\.wpi\\.edu/academics/((facultydir)|(datascience))/", "teacherPage_");
			HttpRequest response = HttpRequest.get(link);
			File f = new File(fileName);
			response.receive(f);
			pages.add(f);
		}
		return pages;
	}
	
	//���߳�ץȡ
	public void CrawlMT() throws IOException, InterruptedException{
		ArrayList<String> linkList = getURLs();
		for (String link : linkList){
			String fileName = "pages/" + link.replaceAll("http://www\\.wpi\\.edu/academics/((facultydir)|(datascience))/", "teacherPage_");
			HttpRequest response = HttpRequest.get(link);
			File f = new File(fileName);
			response.receive(new File(fileName));
			buffer.addToWaitList(f);		
		}
		flag = true;
	}
	
	public void run(){
		try {
			CrawlMT();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}

