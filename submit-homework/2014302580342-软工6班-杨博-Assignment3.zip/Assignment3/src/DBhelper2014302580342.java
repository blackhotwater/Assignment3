import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBhelper2014302580342 {
	private static String url = "jdbc:mysql://127.0.0.1:3306/teacherInfo?"+
	"user=root&password=123456";
	
	private static Connection getConnection(String url) {
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url);
			return conn;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	static int insert(TeacherInfo2014302580342 teacher) {
	    Connection conn = getConnection(url);
	    int i = 0;
	    String sql = "insert into teachers (name,email,title,researchInterests) values(?,?,?,?)";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        pstmt.setString(1, teacher.getName());
	        pstmt.setString(2, teacher.getEmail());
	        pstmt.setString(3, teacher.getPersonalInfo());
	        pstmt.setString(4, teacher.getResearchInterests());
	        i = pstmt.executeUpdate();
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return i;
	}
	
	static void select() {
	    Connection conn = getConnection(url);
	    String sql = "select * from teachers";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement)conn.prepareStatement(sql);
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
}