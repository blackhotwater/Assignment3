import java.io.File;
import java.util.ArrayList;


public class Buffer2014302580342 {
	private ArrayList<File> waitList = new ArrayList<File>();
	private boolean flag = false;
	public Buffer2014302580342(ArrayList<File> waitList) {
		this.waitList = waitList;
	}
	public synchronized void addToWaitList(File page) throws InterruptedException{
		while(flag){
			wait();
		}
		waitList.add(page);
		flag = true;
		notifyAll();
	}

	public synchronized File getFile() throws InterruptedException {
		while(!flag){
			wait();
		}
		File page = waitList.get(0);
		flag = false;
		waitList.remove(0);
		notifyAll();
		return page;
	}
}
