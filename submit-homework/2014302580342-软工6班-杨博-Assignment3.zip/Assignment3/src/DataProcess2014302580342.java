import java.io.File;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class DataProcess2014302580342 implements Runnable{
	Buffer2014302580342 buffer;
	DataProcess2014302580342(Buffer2014302580342 b){
		this.buffer = b;
	}
	public static Document getDoc(File fileName)throws IOException{
		Document doc = Jsoup.parse(fileName,"GBK");
		return doc;
	}
	
	//��jsoup��ѡ�������ҳ����ڵĸ�����Ϣ
	//����
	public String getName(Document doc){
		String name = "";
		Elements n = doc.select("#content h2");
		name = n.text();
		return name;
	}
	//��ϵ��ʽ
	public String getAddress(Document doc){
		String email = "";
		Elements n = doc.select("#contactinfo a");
		email = n.text();
		return email;
	}
	//���
	public String getInfo(Document doc){
		String info = "";
		Elements Info = doc.select(".titles li");
		info = Info.text();
		return info;
	}
	//�о�����
	public String getResearchInterests(Document doc){
		String ResearchInterests = "";
		Elements Interests = doc.select(".col li");
		for (Element Interest  : Interests) {
			ResearchInterests  += "" + Interest.text(); 
		}
		return ResearchInterests;
	}
	//�ѻ�����ϴ���������
	public TeacherInfo2014302580342 getAllData(File fileName) throws IOException{
		Document doc = getDoc(fileName);
		TeacherInfo2014302580342 info = new TeacherInfo2014302580342();
		info.setName(getName(doc));
		info.setEmail(getAddress(doc));
		info.setResearchInterests(getResearchInterests(doc));
		info.setPersonalInfo(getInfo(doc));
		DBhelper2014302580342.insert(info);
		return info;
	}
	
	public void run(){
		while(true){
			try {
				getAllData(buffer.getFile());
			} catch (IOException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		if (Crawler2014302580342.flag) {
				break;
			}
		}
	}
	
}